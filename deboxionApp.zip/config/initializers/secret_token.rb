# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
DeboxionApp::Application.config.secret_token = '3ee7fee469063833401573bd64431f056d62ff24e9d4ffeff83540532832f75aaa9e509601577f4dcf2f06358ea3ebf2dc709a7bf6df87ab1325f307cc8fe2bc'
